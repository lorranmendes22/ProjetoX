/* 
 * File:   principais.h
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:28
 */

#ifndef PRINCIPAIS_H
#define	PRINCIPAIS_H

#include "def_principais.h"
#include "lcd.h"


void config(void);
void config2(void);
void servo_pwm(void);
unsigned char maq_estados(unsigned char estado);
unsigned char le_teclado(unsigned char teclado);

ISR(PCINT0_vect);

#endif	/* PRINCIPAIS_H */

