/* 
 * File:   def_principais.h
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:30
 */

#ifndef DEF_PRINCIPAL_H
#define	DEF_PRINCIPAL_H

/* ----------- Bibliotecas ---------------- */
#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <avr/interrupt.h>

/* ---------  Defini��es (Macros)-------   */
/*  Mascaras de bits*/
#define F_CPU 16000000UL //clock do processador 16 mega heatz
#define set_bit(y,bit) (y|=(1<<bit))  // coloca 1 num bit especifico
#define clr_bit(y,bit) (y&=~(1<<bit)) // coloca 0 num bit especifico
#define tgl_bit(y,bit) (y^=(1<<bit))  // inverte estado de um  bit especifico
#define tst_bit(y,bit) (y&=(1<<bit))  // retona 0 ou 1 conforme leitura do bit

#define TRUE 1
#define FALSE 0
#define TAM 17 //msg display
#define TOP 39999 //50Hz PWM
#define TMIN 1999 //pulso 1ms
#define TMAX 2999 //pulso 1.5ms
#endif	/* DEF_PRINCIPAIS_H */

