/*
 * File:   main_a.c
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:25
 */

#ifndef DEF_PRINCIPAL_H
#define	DEF_PRINCIPAL_H

/* ----------- Bibliotecas ---------------- */
#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <avr/interrupt.h>

/* ---------  Defini��es (Macros)-------   */
/*  Mascaras de bits*/
#define F_CPU 16000000UL //clock do processador 16 mega heatz
#define set_bit(y,bit) (y|=(1<<bit))  // coloca 1 num bit especifico
#define clr_bit(y,bit) (y&=~(1<<bit)) // coloca 0 num bit especifico
#define tgl_bit(y,bit) (y^=(1<<bit))  // inverte estado de um  bit especifico
#define tst_bit(y,bit) (y&=(1<<bit))  // retona 0 ou 1 conforme leitura do bit

#define TRUE 1
#define FALSE 0
#define TAM 17 //msg display
#define TOP 39999 //50Hz PWM
#define TMIN 1999 //pulso 1ms
#define TMAX 2999 //pulso 1.5ms
#endif	/* DEF_PRINCIPAIS_H */

#include "def_principais.h"

int main(void){
//variaveis
unsigned char estado = 4;
unsigned char state = 0;
unsigned char ctrl = 0;
unsigned char ctrl2 = 0;

config(); //configura��o dos perifericos
inic_lcd(); // inicializa lcd
sei(); // habilita a chave geral das interrup��es


config2(); //configura��o PWM SERVO MOTOR
servo_pwm(); // fun��o PWM

    while (1){
        estado = maq_estados(estado);
        
        switch(state){
            case 0:
                if(!(PINC&0x10)){ //SENSOR PRESEN�A
                    state = 1;
                }
                         
            break;
            
            case 1:
                if(!(PINC&0x08)){ //SENSOR TICKET
                    state = 2;
                }
                
                if(PINC&0x10){
                    state = 0;
                }
                               
            break;
            
            case 2:
                if(PINC&0x08){ //SENSOR TICKET
                    state = 3;
                }

            break;
            
            case 3:
                for(int i = TMIN; i < TMAX; i++){
                    OCR1B = i;
                    _delay_ms(100);
                }
                
                state = 4;

            break;
            
            case 4:
                if(PINC&0x10){ //SENSOR PRESEN�A
                    for(int i = TMAX; i > TMIN; i--){
                        OCR1B = i;
                        _delay_ms(100);
                    }
                    state = 0;
                }

            break;

        }
        
        
        /*       
        if((!(PINC&0x08))&&(ctrl2 == 0)&&(ctrl == 1)){ //PC3 Leitor ticket
            ctrl2 = 1;
            for(int i = TMIN; i < TMAX; i++){
                OCR1B = i;
                _delay_ms(100);
            }
            
        }
        
        if(!(PINC&0x10)){ //PC4 Sensor Presen�a
            ctrl = 1;
        }
        
        if((ctrl == 1)&&(PINC&0x10)&&(ctrl2 == 1)){ //PC4 Sensor Presen�a
            ctrl = 0;
            ctrl2 = 0;
            for(int i = TMAX; i > TMIN; i--){
                OCR1B = i;
                _delay_ms(100);
            }
        }
        */
        //for(int i = TMAX; i > TMIN; i--){
        //    OCR1B = i;
        //        _delay_ms(100);
        //    }
    }
}
       
        

unsigned char le_teclado(void){
    unsigned char tecla = 0xFF;
    const unsigned char teclado[4][3] = {{'1', '2', '3'},
                                         {'4', '5', '6'},
                                         {'7', '8', '9'},
                                         {'*', '0', '#'}};
    
    for(int i = 0; i < 3; i++)
        set_bit(PORTC, i);
    
    for(int i = 0; i < 3; i++){
        clr_bit(PORTC, i);              //Ativa a leitura da coluna 1
        _delay_ms(100);
        
        for(int j = 0; i < 4; j++){
            
            if(!(PIND&1<<j)){
                tecla = teclado[j][i];
                while(!(PIND&1<<j));    //Aguarda soltar da coluna 1
            }
        }
        set_bit(PORTC, i);              //Desativa a leitura da coluna 1
    }
    return tecla;

}
