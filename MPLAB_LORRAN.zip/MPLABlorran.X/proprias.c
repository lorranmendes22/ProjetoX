/*
 * File:   principais.c
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:21
 */

#include "proprias.h"


void config(void){
/*--------------------Configura��o Caracteres-----------------------------*/
    DDRD = 0xff;  // todos bits do port D como saida
    set_bit(DDRB,PB0); // configura PB0 como saida
    set_bit(DDRB,PB1); // configura PB1 como saida
    set_bit(PORTB,PB2); // ativa resistor de pull up do pino B2
    //set_bit(PORTB,PB3); // ativa resistor de pull up do pino B3
    set_bit(PORTB,PB4); // ativa resistor de pull up do pino B4
  
/*--------------------Configura��o teclado------------------------------*/
    set_bit(PORTD,PD0); // ativa resistor de pull up do pino D0
    set_bit(PORTD,PD1); // ativa resistor de pull up do pino D1
    set_bit(PORTD,PD2); // ativa resistor de pull up do pino D2
    set_bit(PORTD,PD3); // ativa resistor de pull up do pino D3
    
 /*--------------------------sensor de temperatura-------------------*/
    set_bit(PORTC,PC3); // ativa resistor de pull up do pino PC3
    
 /*------------------------------------------------------------------*/
    set_bit(DDRC,PC0); // configura PC0 como saida
    set_bit(DDRC,PC1); // configura PC1 como saida
    set_bit(DDRC,PC2); // configura PC2 como saida
    
/*--------------------Configura��o Motor_DC------------------------------*/
    set_bit(DDRC,PC4); // configura PC4 como saida
    set_bit(DDRC,PC5); // configura PC5 como saida
    set_bit(DDRB,PB3); // configura PB3 como saida
   
 
/*--------------------Interrup��es---------------------------------------*/
    set_bit(PCMSK0,PB2); //HABILITA INTERRUP��O DO PINO PB2
    set_bit(PCMSK0,PB3); //HABILITA INTERRUP��O DO PINO PB3
    set_bit(PCMSK0,PB4); //HABILITA INTERRUP��O DO PINO PB4
    set_bit(PCICR,0);// Habilita
    //set_bit(PCINT1,PC3);
    //set_bit(PCINT1,PC4);
    
}

unsigned char maq_estados(unsigned char estado){

    char msg[TAM];
    
    switch(estado){
        case 0:
            _delay_ms(5000);

                //Teste de B2
                
                if(!(PINB&0x04)){
                    cmd_lcd(0x01,0); // limpa LCD
                    strcpy(msg,"Estado atual: 0");
                    escreve_lcd(msg);
                }
                _delay_ms(5000);
                //teste de B3
                if(!(PINB&0x08))
                    estado = 1;
                 
            break;    
            case 1:
                _delay_ms(5000);
                 //Teste de B2
                if(!(PINB&0x04)){
                    cmd_lcd(0x01,0); // limpa LCD
                    strcpy(msg,"Estado atual: 1");
                    escreve_lcd(msg);
                }
                _delay_ms(5000);
                //teste de B3
                if(!(PINB&0x08)){
                    estado = 2;
                }
                //teste de B4
                if(!(PINB&0x10))
                    estado = 0;
            break;
            case 2:
                _delay_ms(5000);
                 //Teste de B2
                if(!(PINB&0x04)){
                    cmd_lcd(0x01,0); // limpa LCD
                    strcpy(msg,"Estado atual: 2");
                    escreve_lcd(msg);
                    _delay_ms(5000);
                }
                //teste de B3
                if(!(PINB&0x08))
                    estado = 3;
                //teste de B4
                if(!(PINB&0x10))
                    estado = 1;
            break;
            case 3:
                _delay_ms(5000); 
                 //Teste de B2
                if(!(PINB&0x04)){
                    cmd_lcd(0x01,0); // limpa LCD
                    strcpy(msg,"Estado atual: 3");
                    escreve_lcd(msg);
                }
                _delay_ms(5000);
                //teste de B4
                if(!(PINB&0x10))
                    estado = 2;
            break;    
        }
    }

// Rotina de tratamento da interrup��o do port b
ISR(PCINT0_vect){
    if (!(PINB&(1<<PB2)))  //foi aciona PB2
        tgl_bit(PORTD,PD7);
        tgl_bit(PORTD,PD6);
}

ISR(PCINT2_vect){

}

void config2(void){
/*-----------------configura��o servo motor-----------------------------*/
    set_bit(DDRB,PB2);

/*-----------------configura��o cancela-----------------------------*/
    set_bit(PORTC,PC3);//ativa resistor de pull up do pino C3
    set_bit(PORTC,PC4);//ativa resistor de pull up do pino C4
    set_bit(PCMSK1,PC3); //HABILITA INTERRUP��O DO PINO PC3
    set_bit(PCMSK1,PC4); //HABILITA INTERRUP��O DO PINO PC4
}

void servo_pwm(void){
    ICR1 = TOP; //39999
    TCCR1A |= (1 << COM1B1) | (1 << WGM11); //OC1B n�o invertido em PB2
    TCCR1B |= (1 << WGM13) | (1 << WGM12)|(1 << CS11) ; //Fast PWM modo 14 e prescale = 8
    
}